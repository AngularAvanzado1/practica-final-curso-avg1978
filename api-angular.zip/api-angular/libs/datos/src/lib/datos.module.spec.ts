import { async, TestBed } from '@angular/core/testing';
import { DatosModule } from './datos.module';

describe('DatosModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [DatosModule],
    }).compileComponents();
  }));

  it('should create', () => {
    expect(DatosModule).toBeDefined();
  });
});
