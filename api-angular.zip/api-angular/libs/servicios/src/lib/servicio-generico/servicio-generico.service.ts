import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Regiones, Continental} from '@api-angular/datos';

@Injectable({
  providedIn: 'root'
})
export class ServicioGenericoService {

  private apiUrl = 'http://api.worldbank.org/v2/region/?format=json';
  constructor(private httpClient: HttpClient) {}

  public getRegiones(): Observable<Regiones[]> {
    console.count('get AMOUNT calls');
    return this.httpClient.get<Regiones[]>(this.apiUrl);
  };
  // public getContinentalRegiones(): Observable<Continental[]> {
  //   return this.httpClient.get<Continental[]>(this.apiUrl);
  // };
}


