import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { async, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { ServicioGenericoService } from './servicio-generico.service';

describe('GIVEN: a ServicioGenericoService', () => {
  describe('WHEN: the ServiciosModule is compiled', () => {
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [HttpClientTestingModule]
      });
    });

    it('THEN: should be created', () => {
      const service: ServicioGenericoService = TestBed.inject(ServicioGenericoService);
      expect(service).toBeTruthy();
    });

    it(`THEN: should return an observable when call 'getRegiones()'`, () => {
      const service: ServicioGenericoService = TestBed.inject(ServicioGenericoService);
      const regiones$: Observable<any> = service.getRegiones();
      expect(regiones$).toBeInstanceOf(Observable);
    });

    it(`THEN: should return '// 20200606124412' when call 'getRegiones()'`, async(() => {
      const service: ServicioGenericoService = TestBed.inject(ServicioGenericoService);
      service
        .getRegiones()
        .subscribe(result =>
          expect(result).toEqual({ message: '// 20200606124412' })
        );
      const httpMock = TestBed.inject(HttpTestingController);
      const req = httpMock.expectOne('http://api.worldbank.org/v2/region/?format=json');
      req.flush({ message: '// 20200606124412' });
      httpMock.verify();
    }));
  });
});
