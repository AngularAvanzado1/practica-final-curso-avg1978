export * from './lib/servicios.module';
export * from './lib/servicio-generico/servicio-generico.service';
