import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { Continental } from '@api-angular/datos';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'aa-apicont-country-region',
  templateUrl: './country-region.component.html',
  styleUrls: ['./country-region.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CountryRegionComponent implements OnInit {

  public regionesCountry$: Observable<Continental[]>; //como vamos a usar el pipe de Async necesitamos que sea un observable
  public regionesCountry: any[];
  public idCountry ="";
  private api = 'http://api.worldbank.org/V2/country/';
  private url = '?format=json ';
  public apiUrl= "";
  public pais: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
    ) {
        this.activatedRoute.params.subscribe(params => {
          console.log(JSON.stringify(params));
          this.apiUrl = "";
          this.idCountry = JSON.stringify(params.idRegion);
          this.idCountry = this.idCountry.replace(/["']/g, "");
          this.apiUrl = this.api+ this.idCountry + this.url;
        })
        this.regionesCountry = [];
        this.pais = '';
  }

  ngOnInit(): void {
    this.regionesCountry$ = this.http.get<Continental[]>(this.apiUrl);
    this.regionesCountry$.subscribe({ next: res => {
      // this.regionesCountry.push(res[1]);
      this.regionesCountry = [...this.regionesCountry, res[1]];
      console.count('get AMOUNT calls');
      this.cdr.detectChanges();
    }});
  }
}
