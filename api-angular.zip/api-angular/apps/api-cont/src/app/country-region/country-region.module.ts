import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { CountryRegionRoutingModule } from './country-region-routing.module';
import { CountryRegionComponent } from './country-region.component';

const routes: Routes = [
  { path: '', component: CountryRegionComponent }
];

@NgModule({
  declarations: [CountryRegionComponent],
  imports: [
    CommonModule,
    CountryRegionRoutingModule,
    RouterModule.forChild(routes)
  ]
})
export class CountryRegionModule { }
