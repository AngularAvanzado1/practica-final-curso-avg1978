import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CountryRegionComponent } from './country-region.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('GIVEN: an CountryRegionComponent in CountryRegionModule', () => {

  let component: CountryRegionComponent;
  let fixture: ComponentFixture<CountryRegionComponent>;
  describe('WHEN: the CountryRegionModule is compiled', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountryRegionComponent ],
      imports: [RouterTestingModule, HttpClientTestingModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryRegionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('THEN: should create the component', () => {
    expect(component).toBeTruthy();
  });
});
});
