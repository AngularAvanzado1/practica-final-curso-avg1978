import { Component, OnInit } from '@angular/core';
import { SwUpdate, SwPush } from '@angular/service-worker';

@Component({
  selector: 'aa-apicont-root',
  templateUrl: './app.component.html',
  styles: [

  ],
})
export class AppComponent implements OnInit{
  title = 'api-cont';
  constructor(
    private swUpdate: SwUpdate, //Inyectamos este servicio por el cual nos podremos subscribir a los cambios que se vayan detectando
    private swPush: SwPush // Este servicio se usa para las notificaciones Push
  ) {

  }

  ngOnInit(){
    this.checkVersionUpdates();
     // this.subscribeToNotifications();
  }

  private checkVersionUpdates() {
    if (this.swUpdate.isEnabled) { //Compruba si el serviceworkerUpdate esta habilitado o no
      this.swUpdate.checkForUpdate().then( data => console.log(data)); //Es una promesa this.swUpdate.checkForUpdate(). Con esto forzamos la detección del cambio
      this.swUpdate.available.subscribe(event => {  //Al estar habilitado nos subscribimos a versión disponible del swUpdate this.swUpdate.available.subscribe. Available es la actualización que hay disponible. Es un observable
        if (event.current.appData) { //Como es un Observable vamos a recibir un event y el tipo de evento puede ser current(actual), available(nueva versión disponible) y type(tipo de actualziación que es). Aquí obtengo el appData(que es la cabecera donde vemos la versión y el changelog), del evento que es el resultado del observable
          const appData: any = event.current.appData;
          let msg = `New version ${appData.version} available.`;
          msg += `${appData.changelog}.`;
          msg += 'Reaload now?';
          if (confirm(msg)) {
            window.location.reload();
          }
        }
      });
    }
  }
  private subscribeToNotifications() {
    if (this.swPush.isEnabled) { //Si el serviceworkerPush esta habilitado
      this.swPush
      .requestSubscription({ serverPublicKey: 'VAPID_PUBLIC_KEY' }) //requestSubscription llama a un servidor de mensajeria externo al que tu pagas o te suscribes y te daran una clave, con esta clave el cliente emite hacia el servidor una notificación diciendole me gustaría recibir notificaciones y el servidor le devuelve un codigo único para ese cliente
      .then(sub => {
        console.log('subscription to server', sub.toJSON()); //Este código habría que mandarlo a nuestro servidor de la forma que sea. EL código sería el sub
        this.swPush.messages.subscribe(msg => console.log('Received: ', msg));
      })
      .catch(err => console.error('Could not subscribe', err));
    }
  }
}
