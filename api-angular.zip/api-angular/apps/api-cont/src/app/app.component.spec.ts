import { ServiciosModule} from '@api-angular/servicios';
import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { DatosModule } from '@api-angular/datos';
import { ServiceWorkerModule } from '@angular/service-worker';

describe('GIVEN: an AppComponent declared in AppModule', () => {
  describe('WHEN: the AppModule is compiled', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,  HttpClientTestingModule, DatosModule, ServiceWorkerModule.register('ngsw-worker.js', { enabled: false })],
      declarations: [AppComponent],
    }).compileComponents();
  }));

  it('THEN: should create the component', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`THEN: should have a property title with value 'api-cont'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('api-cont');
  });






});

});
