import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { Continental } from '@api-angular/datos';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'aa-apicont-continental-region',
  templateUrl: './continental-region.component.html',
  styleUrls: ['./continental-region.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContinentalRegionComponent implements OnInit {

  public regionesContinental$: Observable<Continental[]>; //como vamos a usar el pipe de Async necesitamos que sea un observable
  public regionesContinental: any[];
  private api = 'http://api.worldbank.org/v2/region/';
  public codeCountry ="";
  private url = '/country?per_page=1000&format=json';
  public apiUrl= "";
  public continente: String;
  public pais: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
    ) {
        this.apiUrl = '';
          this.activatedRoute.params.subscribe(params => {
          console.log(JSON.stringify(params));
          this.apiUrl = '';
          this.codeCountry = JSON.stringify(params.idCode);
          this.codeCountry = this.codeCountry.replace(/["']/g, "");
        })
        this.apiUrl = this.api+ this.codeCountry + this.url;
        this.regionesContinental= [];
      }

  ngOnInit(): void {
    this.regionesContinental$ = this.http.get<Continental[]>(this.apiUrl);
    this.regionesContinental$.subscribe({ next: res => {
      this.pais = (JSON.stringify(res[1]));
      //  this.regionesContinental.push(res[1]);
      this.regionesContinental = [...this.regionesContinental, res[1]];
      console.count('get AMOUNT calls');
      //Recorremos el resultado de nuevo para mostrar el nombre del continente
      for(let i = 0; i < Object.values(res[1]).length; i++) {
        this.continente = Object.values(res[1])[i]['region']['value'];
      }
      this.cdr.detectChanges();
    }
    });
  }
}
