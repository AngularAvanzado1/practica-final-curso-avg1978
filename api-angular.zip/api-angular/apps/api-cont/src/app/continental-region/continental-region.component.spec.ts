import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContinentalRegionComponent } from './continental-region.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('GIVEN: an ContinentalRegionComponent in ContinentalRegionModule', () => {

  let component: ContinentalRegionComponent;
  let fixture: ComponentFixture<ContinentalRegionComponent>;
  describe('WHEN: the ContinentalRegionModule is compiled', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContinentalRegionComponent ],
      imports: [RouterTestingModule, HttpClientTestingModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContinentalRegionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('THEN: should create the component', () => {
    expect(component).toBeTruthy();
  });


});
});
