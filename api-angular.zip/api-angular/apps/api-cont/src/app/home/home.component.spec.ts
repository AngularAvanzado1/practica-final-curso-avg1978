import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RegionesComponent } from './regiones/regiones.component';

describe('GIVEN: an RegionesComponent declared in HomeModule', () => {

  describe('WHEN: the HomeModule is compiled', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegionesComponent, HomeComponent ],
      imports: [RouterTestingModule, HttpClientTestingModule, ReactiveFormsModule],
    })
    .compileComponents();
  }));

  it('THEN: should create the component', () => {
    const fixture = TestBed.createComponent(HomeComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });


});
});
