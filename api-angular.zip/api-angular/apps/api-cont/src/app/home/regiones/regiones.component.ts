import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { Regiones } from '@api-angular/datos';

@Component({
  selector: 'aa-apicont-regiones',
  templateUrl: './regiones.component.html',
  styleUrls: ['./regiones.component.css'],
})
export class RegionesComponent implements OnInit {
  @Input() regiones: Regiones[] = []

  //Filtrar por  region por país
  public idCode: any[];

  constructor(
    private router: Router,
    private fb: FormBuilder,
  ) { }

  filtrarIdForm = this.fb.group({
    id: [''],
    code: [''],
    iso2code: [''],
    name: ['']
  })

  onSubmit() {
    alert(JSON.stringify(this.filtrarIdForm.value))
  }

  //Continental region
  changeSuit(e) {
    this.filtrarIdForm.get('code').setValue(e.target.value, {
       onlySelf: true

    })

    this.idCode = e.target.value
    this.router.navigate(['continental-region', this.idCode]).then( (e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });
  }

  ngOnInit(): void {
  }

}
