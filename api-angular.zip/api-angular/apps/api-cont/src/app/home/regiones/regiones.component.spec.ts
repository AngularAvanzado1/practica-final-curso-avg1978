import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RegionesComponent } from './regiones.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';

describe('GIVEN: an RegionesComponent declared in HomeModule', () => {
  describe('WHEN: the HomeModule is compiled', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegionesComponent ],
      imports: [RouterTestingModule, HttpClientTestingModule, ReactiveFormsModule],
    })
    .compileComponents();
  }));

  it('THEN: should create the component', () => {
    const fixture = TestBed.createComponent(RegionesComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`THEN: should render 'REGIONES GEOGRÁFICAS CONTINENTALES' in a H1 tag`, () => {
    const fixture = TestBed.createComponent(RegionesComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('REGIONES GEOGRÁFICAS CONTINENTALES');
  });
});
});

