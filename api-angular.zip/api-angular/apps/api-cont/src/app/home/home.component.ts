import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { Regiones } from '@api-angular/datos';
import { ServicioGenericoService } from '@api-angular/servicios';

@Component({
  selector: 'aa-apicont-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  // changeDetection: ChangeDetectionStrategy.Default,
})
export class HomeComponent implements OnInit {
  public regiones$: Observable<Regiones[]>; //como vamos a usar el pipe de Async necesitamos que sea un observable
  public regiones: any[]
  constructor(
    private servicioGenericoService: ServicioGenericoService,
      private cdr: ChangeDetectorRef //con esto va a detectar los cambios con su metodo detectChanges, hay que inyectarle en el constructor
  ) {
    this.regiones = []
  }

  ngOnInit(): void {
    this.regiones$ = this.servicioGenericoService.getRegiones();
    this.regiones$.subscribe({ next: res => {
      this.regiones = [...this.regiones, res[1]];
      console.count('get AMOUNT calls');
      this.cdr.detectChanges();
    }
  });
  }
}
