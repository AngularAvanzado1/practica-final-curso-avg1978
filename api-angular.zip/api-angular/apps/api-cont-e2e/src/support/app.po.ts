export const getTitle= () => cy.get('h1');
export const getRegiones= () => cy.get('section');
