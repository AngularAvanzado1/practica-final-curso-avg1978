import { getTitle} from '../support/app.po';
import { getRegiones } from '../support/app.po';

describe('GIVEN: aplicacion web app', () => {
  beforeEach(() => cy.visit('/'));
  context('WHEN: user visits home page', () => {
    it('THEN: should title', () => {
      getTitle().contains('REGIONES GEOGRÁFICAS CONTINENTALES');
    });

    it('THEN: should display datas from the API', () => {
      getRegiones().contains('EAS');
    });
  });
});

